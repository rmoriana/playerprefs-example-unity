﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoadData : MonoBehaviour {

    int numUsers;
    GameObject textoPuntuaciones;
	
    //Muestra todos los usuarios y puntuaciones guardados.
	void Start () {
        numUsers = PlayerPrefs.GetInt("numUsers");        
        textoPuntuaciones = GameObject.Find("ListaPuntuaciones");
        for (int i = 0; i <= numUsers; i++)
        {
            textoPuntuaciones.GetComponent<Text>().text += "Nombre: " + PlayerPrefs.GetString("Nombre_" + i)+"   Puntos: " + PlayerPrefs.GetInt("Puntuacion_"+i) + "\n";
        }
	}	
}
