﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Save : MonoBehaviour {

    GameObject nombreText;
    GameObject puntosText;
    int numUsers;        
	
    //Setup
	void Start () {

        nombreText = GameObject.Find("Nombre");
        puntosText = GameObject.Find("Puntuacion");
        numUsers = 0;        

        while (PlayerPrefs.HasKey("Nombre_" + numUsers))
        {
            numUsers++;
        }
               
    }
	
    //Guarda los datos introducidos.
    public void SaveData()
    {
        if(nombreText.GetComponentInChildren<Text>().text != "" && puntosText.GetComponentInChildren<Text>().text != "")
        {
            PlayerPrefs.SetString("Nombre_" + numUsers, nombreText.GetComponent<InputField>().text);
            PlayerPrefs.SetInt("Puntuacion_" + numUsers, int.Parse(puntosText.GetComponent<InputField>().text));
            PlayerPrefs.SetInt("numUsers", numUsers);
            PlayerPrefs.Save();
            SceneManager.LoadScene("Results");
        }
        else
        {
            Debug.Log("El nombre o la puntuación están vacios.");
        }
        
    }
}
